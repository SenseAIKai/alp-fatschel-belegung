@echo off
title Feratel Deskline WebClient - Alp Fatschel
set "DESKLINE_URL=https://webclient4.deskline.net/ARO/de/accommodation/overview"
set "EDGE_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE_EXE%" set "EDGE_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if exist "%EDGE_EXE%" (
    start "" "%EDGE_EXE%" --app="%DESKLINE_URL%" --window-size=1480,920
    exit /b 0
)
start "" "%DESKLINE_URL%"
exit /b 0
