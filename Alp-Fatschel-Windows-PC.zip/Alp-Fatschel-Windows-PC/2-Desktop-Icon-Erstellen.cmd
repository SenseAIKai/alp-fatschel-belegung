@echo off
chcp 65001 >nul
title Alp Fatschel - Windows Desktop-Symbol einrichten
set "BASE_DIR=%~dp0"
set "TARGET_DIR=%LOCALAPPDATA%\AlpFatschelPMS"

echo ============================================================================
echo   ALP FATSCHEL - WINDOWS DESKTOP-APP INSTALLATION (100%% ANTIVIRUS-CLEAN)
echo ============================================================================
echo.
echo [1/3] Kopiere Programmdateien nach %TARGET_DIR% ...
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
xcopy /E /I /Y "%BASE_DIR%*" "%TARGET_DIR%\" >nul

echo [2/3] Erstelle Desktop-Verknuepfung mit offiziellem Alp Fatschel Icon ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $desk = [Environment]::GetFolderPath('Desktop'); ^
   $lnk = $ws.CreateShortcut((Join-Path $desk 'Alp Fatschél.lnk')); ^
   $lnk.TargetPath = Join-Path '%TARGET_DIR%' '1-Alp-Fatschel-Starten.cmd'; ^
   $lnk.WorkingDirectory = '%TARGET_DIR%'; ^
   $lnk.IconLocation = (Join-Path '%TARGET_DIR%\app' 'Alp-Fatschel.ico') + ',0'; ^
   $lnk.WindowStyle = 7; ^
   $lnk.Description = 'Alp Fatschél Hotel-PMS & Feratel Deskline Belegungsplan'; ^
   $lnk.Save(); ^
   $startMenu = [Environment]::GetFolderPath('Programs'); ^
   $lnk2 = $ws.CreateShortcut((Join-Path $startMenu 'Alp Fatschél.lnk')); ^
   $lnk2.TargetPath = Join-Path '%TARGET_DIR%' '1-Alp-Fatschel-Starten.cmd'; ^
   $lnk2.WorkingDirectory = '%TARGET_DIR%'; ^
   $lnk2.IconLocation = (Join-Path '%TARGET_DIR%\app' 'Alp-Fatschel.ico') + ',0'; ^
   $lnk2.WindowStyle = 7; ^
   $lnk2.Save();"

echo [3/3] Starte Alp Fatschel Desktop-App ...
call "%TARGET_DIR%\1-Alp-Fatschel-Starten.cmd"
echo.
echo FERTIG! Das Symbol "Alp Fatschél" liegt jetzt auf deinem Windows-Desktop.
timeout /t 4 >nul
exit /b 0
