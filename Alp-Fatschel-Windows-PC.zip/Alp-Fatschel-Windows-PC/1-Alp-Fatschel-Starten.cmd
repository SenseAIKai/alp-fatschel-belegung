@echo off
chcp 65001 >nul
title Alp Fatschel - Hotel-PMS
set "APP_DIR=%~dp0app"
set "LOCAL_HTML=%APP_DIR%\index.html"
set "LIVE_URL=https://senseaikai.github.io/alp-fatschel-belegung/"

REM Nutzt die von Microsoft signierte Windows Edge App-Engine (100%% Antivirus-sicher, keine fremden Hooks)
set "EDGE_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE_EXE%" set "EDGE_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if exist "%EDGE_EXE%" (
    if exist "%LOCAL_HTML%" (
        start "" "%EDGE_EXE%" --app="file:///%LOCAL_HTML:\=/%" --window-size=1520,940
    ) else (
        start "" "%EDGE_EXE%" --app="%LIVE_URL%" --window-size=1520,940
    )
    exit /b 0
)

REM Fallback auf Google Chrome App-Modus oder Standard-Browser
set "CHROME_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME_EXE%" set "CHROME_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"

if exist "%CHROME_EXE%" (
    if exist "%LOCAL_HTML%" (
        start "" "%CHROME_EXE%" --app="file:///%LOCAL_HTML:\=/%" --window-size=1520,940
    ) else (
        start "" "%CHROME_EXE%" --app="%LIVE_URL%" --window-size=1520,940
    )
    exit /b 0
)

if exist "%LOCAL_HTML%" (
    start "" "%LOCAL_HTML%"
) else (
    start "" "%LIVE_URL%"
)
exit /b 0
