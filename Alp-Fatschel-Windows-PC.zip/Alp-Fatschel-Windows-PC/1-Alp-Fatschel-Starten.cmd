@echo off
title Alp Fatschel - Hotel-PMS
set "TARGET_DIR=%LOCALAPPDATA%\AlpFatschelPMS"
set "LOCAL_HTML=%TARGET_DIR%\index.html"
set "LIVE_URL=https://senseaikai.github.io/alp-fatschel-belegung/"

if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
if exist "%~dp0app\index.html" copy /Y "%~dp0app\index.html" "%LOCAL_HTML%" >nul
if not exist "%LOCAL_HTML%" (
    where curl.exe >nul 2>nul
    if %ERRORLEVEL% EQU 0 (
        curl.exe -fsSL "https://senseaikai.github.io/alp-fatschel-belegung/index.html" -o "%LOCAL_HTML%"
    )
)

set "EDGE_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE_EXE%" set "EDGE_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if exist "%EDGE_EXE%" (
    if exist "%LOCAL_HTML%" (
        start "" "%EDGE_EXE%" --app="file:///%LOCAL_HTML:\=/%" --window-size=1520,940
    ) else (
        start "" "%EDGE_EXE%" --app="%LIVE_URL%" --window-size=1520,940
    )
    exit /b 0
)

set "CHROME_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME_EXE%" set "CHROME_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"

if exist "%CHROME_EXE%" (
    if exist "%LOCAL_HTML%" (
        start "" "%CHROME_EXE%" --app="file:///%LOCAL_HTML:\=/%" --window-size=1520,940
    ) else (
        start "" "%CHROME_EXE%" --app="%LIVE_URL%" --window-size=1520,940
    )
    exit /b 0
)

start "" "%LIVE_URL%"
exit /b 0
